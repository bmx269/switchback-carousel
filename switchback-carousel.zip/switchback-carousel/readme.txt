=== Switchback Carousel ===
Contributors: bmx269
Tags: carousel, slider, slideshow, posts carousel, blocks
Requires at least: 6.7
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 0.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Accessible carousel blocks for WordPress. Build slides by hand, or turn any Query Loop into a carousel. Works with Advanced Query Loop.

== Description ==

Switchback Carousel adds carousel blocks built from parts you arrange freely in the editor: the **track** that moves, the **slides**, and **controls** that can sit anywhere inside the carousel, even inside a slide. Controls include previous/next arrows, pagination, a progress bar, a slide counter and a play/pause button.

**[Try it in WordPress Playground](https://playground.wordpress.net/?blueprint-url=https://raw.githubusercontent.com/bmx269/switchback-carousel/main/blueprint.json)**. No installation needed.

= Hand-built or from your posts =

Build slides yourself with any blocks. For posts, select a **Query Loop** and turn on **Display as carousel**: every post becomes a slide, designed once in the Post Template. Post Title, Featured Image, Excerpt, Date and anything else you'd put in a Query Loop work as usual, and the editor shows the posts as a row of slides while you design.

= Works with Advanced Query Loop =

Need more than core's Query Loop filters? Install [Advanced Query Loop](https://wordpress.org/plugins/advanced-query-loop/) and filter by post meta and SCF/ACF fields, dates, multiple post types, specific posts and more. Switchback handles the display and AQL handles the query, both on the same block.

In AQL's meta query values, use relative dates like `{today}`, `{today+7}` or `{today_ymd}` for "upcoming" carousels that never go stale.

= Settings =

* Slides side by side, slides per move and a peek at the next slide, set separately for desktop, tablet and phones by switching the editor's device preview
* Fluid columns for post carousels: set a minimum slide width and fit as many slides as the screen allows
* Slides aligned from the start or centered; narrowest and widest slide width
* Slide or fade; stop, rewind or keep going at the last slide
* Snap to slides or glide freely; mouse wheel and trackpad scrolling
* Step-by-step or continuous autoplay, with pause on hover
* Let slides show past the edges for full-bleed layouts, or fade the edges
* Linked layout: rearrange or restyle one slide and the others follow, while each keeps its own content
* Five starter designs: feature cards, quote rotator, latest posts, logo marquee and a gallery strip

= Accessible by default =

Carousels are easy to get wrong for keyboard, screen reader and motion-sensitive visitors. Switchback is built on Splide, which follows the WAI-ARIA carousel pattern, and handles its own controls the same way. Nothing needs switching on.

* Carousel and slide semantics, with each slide labelled by position ("3 of 8")
* Each carousel is named after its heading, or a name you set, so screen reader users can tell several apart
* Slides out of view are hidden from screen readers, and their links leave the Tab order until they scroll into view
* A polite live region announces each new slide, and goes quiet during autoplay so it doesn't interrupt
* Arrow keys move the focused carousel; the track itself takes focus, with a visible outline
* Arrows, pagination and play/pause are real, labelled buttons; arrows are disabled at the ends, and the current page is marked
* The progress bar is a labelled slider that works with the arrow keys, and the counter reads "2 of 6"
* Autoplay pauses while focus is inside the carousel, and optionally on hover
* Reduced motion respected: instant transitions, and both step-by-step and continuous autoplay stay paused until the visitor presses Play
* Every label is translatable
* Without JavaScript, slides remain a native scrollable row instead of disappearing

= For developers =

* Post carousels are ordinary Query Loops: change their queries with `query_loop_block_query_vars` or AQL's `aql_query_vars`
* Saved content contains no slider-library class names, so the markup stays yours
* `window.switchback.mount()`, `unmount()` and `get()` for carousels added to the page after load

= Source code =

The full, human-readable source of the editor and front-end scripts is included in the plugin's `src` folder, with the build configuration in `package.json` (built with `@wordpress/scripts`). Development happens at [github.com/bmx269/switchback-carousel](https://github.com/bmx269/switchback-carousel).

== Installation ==

1. In your dashboard go to **Plugins → Add New**, search for "Switchback Carousel", then install and activate it. Or upload the plugin folder to `/wp-content/plugins/` and activate it on the Plugins screen.
2. In the editor, add a **Switchback Carousel** block, or pick one of the carousel designs from the pattern inserter.
3. Select the **Carousel Track** to set layout, motion and autoplay for hand-built slides, or select a **Query Loop** and turn on **Display as carousel** for posts.

== Frequently Asked Questions ==

= How do I make a carousel of posts or a custom post type? =

Start from the **Latest posts** pattern, or put a Query Loop inside a Switchback Carousel block. Select the Query Loop, turn on **Carousel display → Display as carousel**, and choose the post type and filters in the Query Loop's usual settings. Design one post in the Post Template and every post uses that design.

= Does it work with Advanced Query Loop? =

Yes. Insert an Advanced Query Loop block, set up the query, then turn on **Display as carousel** in the same block's sidebar. AQL handles which posts appear and Switchback handles how they're shown. AQL is optional, and plain Query Loops work too.

= Can I filter by a Secure Custom Fields or ACF field? =

Yes, with Advanced Query Loop's meta query controls. SCF/ACF date pickers store dates as `Ymd`, so compare them with the `{today_ymd}` token. For example, "`event_date` is greater than or equal to `{today_ymd}`" shows upcoming events.

= Where do the arrows and dots go? =

Anywhere inside the carousel. Controls are their own block, so you can place them above or below the slides, add several, or put them inside a slide. Turn on **Arrows over the slides** on the Switchback Carousel block to float the arrows on either side.

= Does it work without JavaScript? =

Yes. Without JavaScript the slides show as a row you can scroll sideways, so no content is hidden.

= Is it accessible? =

Yes, accessibility is built in rather than an option. The carousel follows the WAI-ARIA carousel pattern through Splide: slides are labelled by position, off-screen slides stay out of the Tab order and away from screen readers, a live region announces moves, and arrow keys work when the carousel has focus. Switchback's own controls are real, labelled buttons, and all autoplay, continuous included, stays paused for visitors who prefer reduced motion.

The content is still yours: give each carousel a heading or a Carousel name, give images alt text, keep text over images readable, and add a Play/pause control to any carousel that autoplays, so visitors can stop the motion (WCAG 2.2.2).

== Screenshots ==

1. A posts carousel on the front end, with arrows over the slides.
2. A Query Loop shown as a carousel: turn on Display as carousel and set columns, motion and edges in the block sidebar.
3. Filtering the same carousel with Advanced Query Loop's meta query: hikes longer than ten kilometres.
4. Feature cards and a fading quote rotator with pagination and a pause button.
5. Controls: arrows in seven icons and five weights, pagination, progress, counter and play/pause.
6. Layout per device: slides side by side, slides per move and a peek at the next slide.

== Changelog ==

= 0.2.0 =
* New: "Lazy-load images" track setting. Images in later slides load as the carousel reaches them instead of with the page.
* New: "Carousel name" setting in the Switchback Carousel block's Accessibility panel. Without it, each carousel is named after its heading, so screen readers no longer announce every carousel on a page as just "Carousel".
* Accessibility: continuous autoplay (Auto Scroll) now stays paused for visitors who prefer reduced motion, like step-by-step autoplay already did. The Play button still starts it.
* Accessibility: the play/pause button no longer reports itself as "pressed". Its label alone says what it will do.
* Fix: a carousel set to let slides spill past the edge no longer makes the page scroll sideways.
* Fix: full-width and wide blocks inside a slide, such as a Cover, keep their alignment in the editor instead of shrinking to the content width.
* Fix: the progress bar track stays visible in browsers without color-mix().
* Development: stylesheets are now native nested CSS, flattened at build time with postcss-nesting, instead of Sass.

= 0.1.0 =
* Initial release.

== Upgrade Notice ==

= 0.1.0 =
Initial release.

== Credits ==

* Sliding powered by [Splide](https://splidejs.com/) and the Splide Auto Scroll extension, © Naotoshi Fujita, MIT license.
* Control icons from [Phosphor Icons](https://phosphoricons.com/), MIT license.
